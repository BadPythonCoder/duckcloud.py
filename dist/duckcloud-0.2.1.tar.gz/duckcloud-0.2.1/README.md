# Duckcloud API Wrapper

This is meant for https://duckcloud.pcprojects.tk/apidocs.
Documentation is coming later!!